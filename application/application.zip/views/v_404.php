	<!-- Content & Sidebar -->
	<div class="container-fluid" id="ctn">
		<div class="row section">

			<?php 
				$this->load->view('v_dashboard_side');
			 ?>
			
			<!-- Main Content -->
			<div class="col-md-8">
				404
			</div>
		</div>
	</div>